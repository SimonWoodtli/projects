//create a function that adds two numbers and alerts the sum
function addTwoNums(num1,num2){
  alert(num1+num2)
}
addTwoNums(2,3)
//create a function that multiplys three numbers and console logs the product
function multiThreeNum(num1,num2,num3){
  console.log(num1*num2*num3)
}
multiThreeNum(2,5,10)
//create a function that divides two numbers and returns the remainder
function numModNum(num1,num2){
  alert(num1%num2)
}
numModNum(10,7)
